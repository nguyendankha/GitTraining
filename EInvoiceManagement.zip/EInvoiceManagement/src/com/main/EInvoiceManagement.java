package com.main;

import com.business.CustomersManagement;

public class EInvoiceManagement {
    public static void main(String[] args) {
        CustomersManagement customersManagement = new CustomersManagement();
        customersManagement.eInvoiceManagementProgram();
    }
}
