package com.business;

import com.DAO.CustomersDAO;
import com.objects.Customers;
import com.objects.ForeignCustomers;
import com.objects.VietnameseCustomers;
import java.time.LocalDate;
import java.util.*;

public class CustomersManagement{
    private static Scanner scanner = new Scanner(System.in);
    private List<Customers> customersList;
    private List<VietnameseCustomers> vietnameseCustomersList;
    private List<ForeignCustomers> foreignCustomersList;
    private CustomerDAOImplement customerDAOImplement;

    /**
     * Constructor
     * Initialize 3 lists of customers by CustomerDAOImplement class
     */
    public CustomersManagement() {
        customerDAOImplement = new CustomerDAOImplement();
        this.customersList = customerDAOImplement.readCustomerList();
        this.vietnameseCustomersList = customerDAOImplement.readVietnameseCustomerList();
        this.foreignCustomersList = customerDAOImplement.readForeignCustomerList();
    }

    /**
     * Getters and Setters
     * */
    public List<Customers> getCustomersList() {
        return customersList;
    }

    public void setCustomersList(List<Customers> customersList) {
        this.customersList = customersList;
    }

    public List<VietnameseCustomers> getVietnameseCustomersList() {
        return vietnameseCustomersList;
    }

    public void setVietnameseCustomersList(List<VietnameseCustomers> vietnameseCustomersList) {
        this.vietnameseCustomersList = vietnameseCustomersList;
    }

    public List<ForeignCustomers> getForeignCustomersList() {
        return foreignCustomersList;
    }

    public void setForeignCustomersList(List<ForeignCustomers> foreignCustomersList) {
        this.foreignCustomersList = foreignCustomersList;
    }

    /**
     * MAIN PROGRAM EXECUTION
     */
    public void eInvoiceManagementProgram(){
        String option;
        boolean exit = false;

        showMenu();
        while (true){
            option = scanner.nextLine();
            switch ( option ){
                case "0":
                    System.out.println("Program exited.");
                    exit = true;
                    break;
                case "1":
                    addCustomer(1);
                    break;
                case "2":
                    addCustomer(2);
                    break;
                case "3":
                    showListOfCustomers();
                    break;
                case "4":
                    getTotalQuantityOFEachCustomerType();
                    break;
                case "5":
                    getAveragePaymentOfForeigners();
                    break;
                case "6":
                    showListOfCustomersByYearAndMonth();
                    break;
                default:
                    System.out.println("\n Your option is invalid. Please re-select your option.");
                    break;
            }
            if (exit == true){
                break;
            }
            showMenu();
        }
    }

    /**
     * Add customer to the related list and TXT file by provided customer type
     * @param customerType
     */
    // add customer to list
    public void addCustomer(int customerType){
        if (customerType == 1) {
            // add vietnamese customers
            VietnameseCustomers vietnameseCustomers = enterVietnameseCustomerInformation();
            vietnameseCustomersList.add(vietnameseCustomers);
            customersList.add(vietnameseCustomers);
            customerDAOImplement.addVietnameseCustomerToFile(vietnameseCustomersList);
            customerDAOImplement.addCustomerToFile(customersList);
        } else {
            // add foreign customers
            ForeignCustomers foreignCustomers = enterForeignCustomerInformation();
            foreignCustomersList.add(foreignCustomers);
            customersList.add(foreignCustomers);
            customerDAOImplement.addForeignCustomerToFile(foreignCustomersList);
            customerDAOImplement.addCustomerToFile(customersList);
        }
    }

//    /**
//     * Retrieve Customer list
//     * @return List<Customers>
//     */
//    public List<Customers> getAllCustomers(){
//        List<Customers> tempCustomerList = new ArrayList<>();
//
//        try {
//            Iterator<Customers> iterator = customersList.iterator();
//            while (iterator.hasNext()) {
//                Customers customer = iterator.next();
//                tempCustomerList.add(customer);
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            return tempCustomerList;
//        }
//    }
//
//    /**
//     * Retrieve Vietnamese Customer list
//     * @return List<VietnameseCustomers>
//     */
//    public List<VietnameseCustomers> getVietnameseCustomers(){
//        List<VietnameseCustomers> tempVietnameseCustomersList = new ArrayList<>();
//
//        try {
//            Iterator<VietnameseCustomers> iterator = vietnameseCustomersList.iterator();
//            while (iterator.hasNext()) {
//                VietnameseCustomers customer = iterator.next();
//                tempVietnameseCustomersList.add(customer);
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            return tempVietnameseCustomersList;
//        }
//    }
//
//    /**
//     * Retrieve Foreign Customer list
//     * @return List<ForeignCustomers>
//     */
//    public List<ForeignCustomers> getForeignCustomers(){
//        List<ForeignCustomers> tempForeignCustomersList = new ArrayList<>();
//
//        try {
//            Iterator<ForeignCustomers> iterator = foreignCustomersList.iterator();
//            while (iterator.hasNext()) {
//                ForeignCustomers customer = iterator.next();
//                tempForeignCustomersList.add(customer);
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            return tempForeignCustomersList;
//        }
//    }


    /**
     * Enter all Vietnamese customer information
     * @return VietnameseCustomers
     */
    public VietnameseCustomers enterVietnameseCustomerInformation(){
        System.out.println("\n------------------------------------------------\n");
        System.out.println("ENTER VIETNAMESE CUSTOMER INFORMATION\n");
        // Customer ID - identity
        int customerID = (customersList.size() > 0) ? (customersList.size() + 1) : 1;
        System.out.println("Customer ID: " + customerID);
        // Customer Name
        String customerName = enterCustomerName();
        // Customer Type
        int customerType = selectCustomerType();
        // Customer Quota
        float quota = enterQuota();
        // Customer Used Quantity
        float usedQuantity = enterUsedQuantity();
        // Unit price
        float unitPrice = enterUnitPrice();
        // Invoice Date
        LocalDate invoiceDate = enterInvoiceDate();
        System.out.println("\n------------------------------------------------\n");
        // Add a vietnamese customer
        return new VietnameseCustomers(customerID, customerName, unitPrice, invoiceDate, usedQuantity, customerType, quota);
    }

    /**
     * Enter all Foreign customer information
     * @return VietnameseCustomers
     */
    public ForeignCustomers enterForeignCustomerInformation(){
        System.out.println("\n------------------------------------------------\n");
        System.out.println("ENTER FOREIGN CUSTOMER INFORMATION\n");
        // Customer ID - identity
        int customerID = (customersList.size() > 0) ? (customersList.size() + 1) : 1;
        System.out.println("Customer ID: " + customerID);
        // Customer Name
        String customerName = enterCustomerName();
        // Nationality
        String customerNationality = enterCustomerNationality();
        // Customer Used Quantity
        float usedQuantity = enterUsedQuantity();
        // Unit price
        float unitPrice = enterUnitPrice();
        // Invoice Date
        LocalDate invoiceDate = enterInvoiceDate();
        System.out.println("\n------------------------------------------------\n");

        // Add a vietnamese customer
        return new ForeignCustomers(customerID, customerName, unitPrice, invoiceDate, usedQuantity, customerNationality);
    }


    /**
     * Enter customer name by scanner
     * @return customerName
     */
    public String enterCustomerName(){
        System.out.println("Enter Customer Name: ");
        String customerName = scanner.nextLine();
        return customerName;
    }

    /**
     * Enter unit price by scanner
     * @return unitPrice
     */
    public float enterUnitPrice() {
        // Unit price
        System.out.println("Enter Unit Price: ");
        while (true) {
            try {
                float unitPrice = Float.parseFloat(scanner.nextLine());
                return unitPrice;
            } catch (Exception ex) {
                System.out.println("\nUnit price is invalid. Please re-enter unit price.\n");
            }
        }
    }

    /**
     * Enter quantity by scanner
     * @return quantity
     */
    public float enterUsedQuantity(){
        // Customer Used Quantity
        System.out.println("Enter Customer Used Quantity: ");
        while (true) {
            try {
                float usedQuantity = Float.parseFloat(scanner.nextLine());
                return usedQuantity;
            } catch (Exception e) {
                System.out.println("\nCustomer used quantity is invalid. Please re-enter used quantity number.\n");
            }
        }
    }

    /**
     * Enter customer nationality by scanner
     * @return customerNationality
     */
    public String enterCustomerNationality(){
        System.out.println("Enter Customer Nationality: ");
        String customerNationality = scanner.nextLine();
        return customerNationality;
    }

    /**
     * Enter quota by scanner
     * @return quota
     */
    public float enterQuota(){
        System.out.println("Enter Customer Quota: ");
        while (true) {
            try {
                float quota = Float.parseFloat(scanner.nextLine());
                return quota;
            } catch (Exception e) {
                System.out.println("\nQuota is invalid. Please re-enter quota.\n");
            }
        }
    }

    /**
     * Select customer type by scanner
     * @return customerType
     */
    public int selectCustomerType(){
        System.out.println("Select Customer Type: \n");
        System.out.println("1. Expenses \n2. Business\n3. Manufacture\n");
        while (true) {
            try {
                int customerType = Integer.parseInt(scanner.nextLine());
                if (customerType != 1 && customerType != 2 && customerType != 3) {
                    throw new Exception();
                } else {
                    return customerType;
                }
            } catch (Exception e) {
                System.out.println("\nInvalid customer type. Please re-select customer type.\n");
            }
        }
    }


    /**
     * Append invoice Day/Month/Year from 3 sub-methods into invoiceDate
     * @return LocalDate invoiceDate
     */
    public LocalDate enterInvoiceDate(){
        System.out.println("Enter Invoice Date:\n");
        while (true){
            try {
                int day = enterInvoiceDay();
                int month = enterInvoiceMonth();
                int year = enterInvoiceYear();
                if (LocalDate.of(year, month, day).isBefore(LocalDate.now()) || LocalDate.of(year, month, day).isEqual(LocalDate.now())) {
                    return LocalDate.of(year, month, day);
                } else {
                    throw new Exception();
                }
            } catch (Exception e) {
                System.out.println("\nEntered invoice date is not valid. Please re-enter the date before or equal today");
            }
        }
    }

    /**
     * Enter invoice Day by scanner
     * @return invoiceDay
     */
    public int enterInvoiceDay(){
        System.out.println("Invoice day: ");
        while (true) {
            try {
                int day = Integer.parseInt(scanner.nextLine());
                if (day <= 0 || day > 31) {
                    throw new Exception();
                } else {
                    return day;
                }
            } catch (Exception e) {
                System.out.println("\nDay is invalid. Please re-enter invoice day.\n");
            }
        }
    }

    /**
     * Enter invoice Month by scanner
     * @return invoiceMonth
     */
    public int enterInvoiceMonth(){
        System.out.println("Invoice month: ");
        while (true) {
            try {
                int month = Integer.parseInt(scanner.nextLine());
                if (month <= 0 || month > 12) {
                    throw new Exception();
                } else {
                    return month;
                }
            } catch (Exception e) {
                System.out.println("\nMonth is invalid. Please re-enter invoice month.\n");
            }
        }
    }

    /**
     * Enter invoice Year by scanner
     * @return invoiceMonth
     */
    public int enterInvoiceYear(){

        System.out.println("Invoice year: ");
        while (true) {
            try {
                int year = Integer.parseInt(scanner.nextLine());
                if (year <= 0 || year <= 1900 || year > LocalDate.now().getYear()) {
                    throw new Exception();
                } else {
                    return year;
                }
            } catch (Exception e) {
                System.out.println("\nYear is invalid. Please re-enter invoice year.\n");
            }
        }
    }

    /**
     * Retrieve total payment for both Vietnamese
     */
    public void getTotalQuantityOFEachCustomerType(){
        float totalQuantityOfVietnamese = 0;
        float totalQuantityOfForeigners = 0;
        String result;
        try {
            Iterator<VietnameseCustomers> vietnameseCustomersIterator = vietnameseCustomersList.iterator();

            while (vietnameseCustomersIterator.hasNext()) {
                VietnameseCustomers vietnameseCustomer = vietnameseCustomersIterator.next();
                totalQuantityOfVietnamese += vietnameseCustomer.getUsedQuantity();
            }

            Iterator<ForeignCustomers> foreignCustomersIterator = foreignCustomersList.iterator();
            while (foreignCustomersIterator.hasNext()) {
                ForeignCustomers foreignCustomer = foreignCustomersIterator.next();
                totalQuantityOfForeigners += foreignCustomer.getUsedQuantity();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        result = ("\n>> Total quantity of Vietnamese customers: " + totalQuantityOfVietnamese + "\n" +
                 (">> Total quantity of Foreign customers: " + totalQuantityOfForeigners));
        frameResult(result);
    }


    /**
     * Calculate the average payment of foreign customers
     */
    public void getAveragePaymentOfForeigners(){
        float totalPaymentOfForeigners = 0;
        float averagePayment = 0;
        String result;
        try {
            Iterator<ForeignCustomers> foreignCustomersIterator = foreignCustomersList.iterator();
            while (foreignCustomersIterator.hasNext()){
                ForeignCustomers customer = foreignCustomersIterator.next();
                totalPaymentOfForeigners += customer.totalPayment();
                if (foreignCustomersList.size() != 0) {
                    averagePayment = totalPaymentOfForeigners/foreignCustomersList.size();
                } else {
                    throw new Exception();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("\nPlease add foreign customer before exporting average payment.\n");
        }
        result = ("\nAverage total payment of foreigners: " + averagePayment);
        frameResult(result);
    }


    /**
     * Show customer list depend on the entered options
     * 1 - All customers
     * 2 - Vietnamese customers
     * 3 - Foreign customers
     */
    public void showListOfCustomers(){
        System.out.println("Select list to show:");
        System.out.println("\n1. All customers\n2. Vietnamese customers\n3. Foreign customers");
        String resultHeader;
        while (true){
            try {
                int typeList = Integer.parseInt(scanner.nextLine());
                if (typeList == 1) {
                    resultHeader = "\nLIST OF ALL CUSTOMERS";
                    frameHeader(resultHeader);
                    for (Customers customer : customersList) {
                        String result = customer.toString();
                        frameResult(result);
                    }
                    break;
                } else if (typeList == 2){
                    resultHeader = "\nLIST OF ALL VIETNAMESE CUSTOMERS\n";
                    frameHeader(resultHeader);
                    for (VietnameseCustomers vietnameseCustomers : vietnameseCustomersList){
                        String result = vietnameseCustomers.toString();
                        frameResult(result);
                    }
                    break;
                } else if (typeList == 3){
                    resultHeader = "\nLIST OF ALL FOREIGN CUSTOMERS";
                    frameHeader(resultHeader);
                    for (ForeignCustomers foreignCustomers : foreignCustomersList){
                        String result = foreignCustomers.toString();
                        frameResult(result);
                    }
                    break;
                } else {
                    throw new Exception();
                }
            } catch (Exception e) {
                System.out.println("\nInvalid type list. Please re-select type list.\n");
            }
        }
    }

    /**
     * Show customer list of the specific year and month
     */
    public void showListOfCustomersByYearAndMonth() {
        for (Customers customer : getCustomersByYearAndMonth()) {
            String result = customer.toString();
            frameResult(result);
        }
    }

    /**
     * Retrieve customer list of the entered year and month
     * @return List<Customers>
     */
    public List<Customers> getCustomersByYearAndMonth(){
        System.out.println("Enter year and month to retrieve customer invoices: ");
        List<Customers> customerListByYearAndMonth = new ArrayList<>();
        int invoiceYear = enterInvoiceYear();
        int invoiceMonth = enterInvoiceMonth();
        while (true) {
            try {
                Iterator<Customers> customersIterator = customersList.iterator();
                while (customersIterator.hasNext()) {
                    Customers customers = customersIterator.next();
                    if (customers.getInvoiceDate().getYear() == invoiceYear && customers.getInvoiceDate().getMonth().getValue() == invoiceMonth) {
                        customerListByYearAndMonth.add(customers);
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                String resultHeader = "\nLIST OF CUSTOMER INVOICES IN " + invoiceYear + " - " + invoiceMonth;
                frameHeader(resultHeader);
                return customerListByYearAndMonth;
            }
        }
    }

    /**
     * String for customizing return result for readability
     * @param string
     */
    public void frameResult(String string){
        StringBuilder builder = new StringBuilder();
        builder.append("\n********************************************");
        builder.append(string);
        System.out.println(builder.toString());
        System.out.println("********************************************");
    }

    /**
     * String for customizing header of function for readability
     * @param string
     */
    public void frameHeader(String string){
        StringBuilder builder = new StringBuilder();
        builder.append("\n********************************************");
        builder.append(string);
        System.out.println(builder.toString());
    }


    /**
     * Menu of the main program
     */
    public void showMenu(){
        System.out.println("\n---------------------E-INVOICE MANAGEMENT SYSTEM---------------------\n");
        System.out.println("\t\t\t|\t0. Exit.\n");
        System.out.println("\t\t\t|\t1. Add Vietnamese customer invoice.\n");
        System.out.println("\t\t\t|\t2. Add Foreign customer invoice.\n");
        System.out.println("\t\t\t|\t3. Show customer invoice list.\n");
        System.out.println("\t\t\t|\t4. Total used quantity (KW).\n");
        System.out.println("\t\t\t|\t5. Average payment of foreign customers.\n");
        System.out.println("\t\t\t|\t6. Show customer invoices of month.\n");
        System.out.println("-----------------------------------------------------------------------\n");
        System.out.println("\t\t\t|\tPLEASE SELECT YOUR OPTION: ");
    }
}